/***************************************************************************/
/*    ALL YOUR HVH NEEDS IN ONE                                                                     */
/*  This is the public version and may not match results of the alpha.*/
/*  For onetap v3              */
/*  Created by Ominous#7262                                         */
/*                                                                         */
/***************************************************************************/
var _$_18a6=["\x62\x61\x63\x6B","\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x46\x61\x6B\x65\x20\x61\x6E\x67\x6C\x65\x73","\x49\x6E\x76\x65\x72\x74\x65\x72","\x49\x73\x48\x6F\x74\x6B\x65\x79\x41\x63\x74\x69\x76\x65","\x54\x6F\x67\x67\x6C\x65\x48\x6F\x74\x6B\x65\x79","\x4D\x69\x73\x63","\x4A\x41\x56\x41\x53\x43\x52\x49\x50\x54","\x53\x63\x72\x69\x70\x74\x20\x49\x74\x65\x6D\x73","\x41\x75\x74\x6F\x2D\x49\x6E\x76\x65\x72\x74\x65\x72","\x47\x65\x74\x56\x61\x6C\x75\x65","\x67\x65\x74\x49\x6E\x76\x65\x72\x74","\x75\x73\x65\x72\x69\x64","\x47\x65\x74\x49\x6E\x74","\x47\x65\x74\x45\x6E\x74\x69\x74\x79\x46\x72\x6F\x6D\x55\x73\x65\x72\x49\x44","\x47\x65\x74\x4C\x6F\x63\x61\x6C\x50\x6C\x61\x79\x65\x72","\x73\x65\x74\x41\x41\x49\x6E\x76\x65\x72\x74","\x20","\x41\x64\x64\x53\x6C\x69\x64\x65\x72\x46\x6C\x6F\x61\x74","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x52\x61\x67\x65\x20\x54\x61\x62\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6E\x74\x69\x41\x69\x6D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x4C\x61\x62\x65\x6C","\x59\x61\x77\x20\x4C\x69\x6D\x69\x74","\x59\x61\x77\x20\x46\x72\x65\x71\x75\x65\x6E\x63\x79","\x59\x61\x77\x20\x43\x65\x6E\x74\x65\x72","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x46\x61\x6B\x65\x6C\x61\x67\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x55\x70\x70\x65\x72\x20\x41\x6E\x64\x20\x4C\x6F\x77\x65\x72\x20\x4C\x69\x6D\x69\x74","\x46\x72\x65\x71\x75\x65\x6E\x63\x79","\x43\x65\x6E\x74\x65\x72\x20\x56\x61\x6C\x75\x65","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x4F\x74\x68\x65\x72\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x64\x64\x43\x68\x65\x63\x6B\x62\x6F\x78","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x54\x65\x73\x74\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x6E\x74\x69\x20\x48\x65\x69\x67\x68\x74\x20\x41\x64\x76\x61\x6E\x74\x61\x67\x65","\x5E\x20\x57\x61\x72\x6E\x69\x6E\x67\x20\x74\x68\x69\x73\x20\x64\x69\x73\x61\x62\x6C\x65\x73\x20\x63\x75\x73\x74\x6F\x6D\x20\x61\x61","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x41\x6E\x74\x69\x2D\x42\x72\x75\x74\x65\x66\x6F\x72\x63\x65","\x4F\x66\x66","\x4F\x6E\x20\x48\x69\x74","\x4F\x6E\x20\x53\x68\x6F\x74","\x41\x64\x64\x44\x72\x6F\x70\x64\x6F\x77\x6E","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x45\x78\x70\x6C\x6F\x69\x74\x20\x20\x54\x61\x62\x20","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x41\x6C\x70\x68\x61\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x54\x72\x69\x70\x70\x6C\x65\x74\x61\x70\x20\x28\x41\x6C\x70\x68\x61\x29\x20\x2D\x20\x63\x61\x75\x73\x65\x73\x20\x69\x6E\x61\x63\x63\x75\x72\x61\x63\x79","\x5E\x20\x46\x69\x72\x73\x74\x20\x73\x68\x6F\x74\x20\x73\x61\x66\x65\x74\x79","\x20\x20\x20\x5E\x20\x73\x65\x63\x6F\x6E\x64\x20\x73\x68\x6F\x74\x20\x73\x61\x66\x65\x74\x79","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x4E\x65\x77\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x50\x65\x72\x66\x65\x63\x74\x54\x61\x70\x20\x28\x4E\x65\x77\x29","\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x42\x65\x74\x61\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D\x2D","\x44\x6F\x75\x62\x6C\x65\x20\x74\x61\x70\x20\x53\x63\x75\x66\x66\x65\x64\x20\x28\x42\x65\x74\x61\x29","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4C\x65\x67\x69\x74\x20\x54\x61\x62\x20","\x46\x72\x65\x65\x73\x74\x61\x6E\x64\x69\x6E\x67\x20\x4C\x65\x67\x69\x74\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x50\x6F\x69\x6E\x74\x20\x64\x69\x73\x74\x61\x6E\x63\x65","\x41\x64\x64\x53\x6C\x69\x64\x65\x72\x49\x6E\x74","\x44\x69\x73\x74\x61\x6E\x63\x65\x20\x63\x6F\x6C\x6F\x72","\x41\x64\x64\x43\x6F\x6C\x6F\x72\x50\x69\x63\x6B\x65\x72","\x4C\x69\x6E\x65\x20\x63\x6F\x6C\x6F\x72","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x57\x61\x74\x65\x72\x6D\x61\x72\x6B","\x47\x65\x74\x53\x63\x72\x65\x65\x6E\x53\x69\x7A\x65","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x78","\x57\x61\x74\x65\x72\x6D\x61\x72\x6B\x20\x79","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x43\x6F\x6E\x73\x6F\x6C\x65","\x45\x6E\x61\x62\x6C\x65\x20\x56\x69\x73\x75\x61\x6C\x20\x4C\x6F\x67\x73","\x45\x6E\x61\x62\x6C\x65\x20\x43\x6F\x6E\x73\x6F\x6C\x65\x20\x4C\x6F\x67\x73","\x20\x20\x20\x20\x20\x43\x72\x65\x61\x74\x65\x64\x20\x42\x79\x20\x4F\x6D\x69\x6E\x6F\x75\x73\x23\x37\x32\x36\x32","\x52\x65\x61\x6C\x74\x69\x6D\x65","\x53\x63\x72\x69\x70\x74\x20\x69\x74\x65\x6D\x73","\x63\x6F\x73","\x52\x61\x67\x65\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x59\x61\x77\x20\x6F\x66\x66\x73\x65\x74","\x53\x65\x74\x56\x61\x6C\x75\x65","\x46\x61\x6B\x65\x2D\x4C\x61\x67","\x4C\x69\x6D\x69\x74","\x50\x49","\x73\x69\x6E","\x73\x71\x72\x74","\x68\x69\x74\x67\x72\x6F\x75\x70","\x43\x75\x72\x74\x69\x6D\x65","\x61\x62\x73","\x78","\x47\x65\x74\x46\x6C\x6F\x61\x74","\x79","\x7A","\x49\x73\x56\x61\x6C\x69\x64","\x49\x73\x45\x6E\x65\x6D\x79","\x49\x73\x44\x6F\x72\x6D\x61\x6E\x74","\x47\x65\x74\x45\x79\x65\x50\x6F\x73\x69\x74\x69\x6F\x6E","\x43\x42\x61\x73\x65\x45\x6E\x74\x69\x74\x79","\x6D\x5F\x76\x65\x63\x4F\x72\x69\x67\x69\x6E","\x47\x65\x74\x50\x72\x6F\x70","\x47\x65\x74\x52\x65\x61\x6C\x59\x61\x77","\x47\x65\x74\x46\x61\x6B\x65\x59\x61\x77","\x47\x65\x74\x57\x65\x61\x70\x6F\x6E","\x47\x65\x74\x4E\x61\x6D\x65","\x67\x33\x73\x67\x31","\x69\x6E\x63\x6C\x75\x64\x65\x73","\x73\x63\x61\x72","\x78\x6D\x31\x30\x31\x34","\x65\x6C\x69\x74\x65","\x64\x65\x73\x65\x72\x74","\x6E\x6F\x76\x61","\x73\x61\x77\x65\x64\x20\x6F\x66\x66","\x52\x61\x67\x65","\x47\x45\x4E\x45\x52\x41\x4C","\x45\x78\x70\x6C\x6F\x69\x74\x73","\x44\x6F\x75\x62\x6C\x65\x74\x61\x70\x20\x66\x61\x73\x74\x20\x72\x65\x63\x6F\x76\x65\x72\x79","\x65\x78\x70\x6C\x6F\x69\x74","\x4C\x65\x67\x69\x74\x20\x41\x6E\x74\x69\x2D\x41\x69\x6D","\x47\x65\x74\x52\x65\x6E\x64\x65\x72\x4F\x72\x69\x67\x69\x6E","\x4C\x69\x6E\x65","\x57\x6F\x72\x6C\x64\x54\x6F\x53\x63\x72\x65\x65\x6E","\x56\x69\x73\x75\x61\x6C\x73","\x57\x6F\x72\x6C\x64","\x56\x69\x65\x77","\x54\x68\x69\x72\x64\x70\x65\x72\x73\x6F\x6E","\x47\x65\x74\x43\x6F\x6C\x6F\x72","","\x53\x74\x72\x69\x6E\x67","\x49\x73\x41\x6C\x69\x76\x65","\x4D\x49\x53\x43","\x43\x43\x53\x50\x6C\x61\x79\x65\x72","\x6D\x5F\x61\x6E\x67\x45\x79\x65\x41\x6E\x67\x6C\x65\x73","\x67\x65\x74","\x72\x65\x76\x65\x72\x73\x65","\x48\x69\x64\x65\x20\x73\x68\x6F\x74\x73","\x47\x65\x6E\x65\x72\x61\x6C","\x53\x74\x72\x69\x63\x74\x20\x73\x61\x66\x65\x74\x79","\x66\x6C\x6F\x6F\x72","\x72\x6F\x75\x6E\x64","\x47\x72\x61\x64\x69\x65\x6E\x74\x20\x53\x70\x65\x65\x64","\x4C\x61\x74\x65\x6E\x63\x79","\x46\x72\x61\x6D\x65\x74\x69\x6D\x65","\x67\x65\x74\x48\x6F\x75\x72\x73","\x67\x65\x74\x4D\x69\x6E\x75\x74\x65\x73","\x67\x65\x74\x53\x65\x63\x6F\x6E\x64\x73","\x30","\x3A","\x54\x69\x63\x6B\x72\x61\x74\x65","\x56\x65\x72\x64\x61\x6E\x61","\x41\x64\x64\x46\x6F\x6E\x74","\x46\x69\x6C\x6C\x65\x64\x52\x65\x63\x74","\x52\x65\x63\x74","\x6F\x6D\x69\x6E\x6F\x75\x73\x77\x61\x72\x65","\x53\x74\x72\x69\x6E\x67\x43\x75\x73\x74\x6F\x6D","\x74\x77\x6F\x20\x73\x74\x65\x70\x73\x20\x61\x68\x65\x61\x64\x20\x6F\x66\x20\x74\x68\x65\x20\x72\x65\x73\x74","\x47\x72\x61\x64\x69\x65\x6E\x74\x52\x65\x63\x74","\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20","\x7C","\x6D\x73","\x70\x69\x6E\x67\x20\x20\x20","\x66\x70\x73\x20\x20\x20","\x46\x61\x6B\x65\x20\x3D\x20","\x74\x6F\x46\x69\x78\x65\x64","\x52\x65\x61\x6C\x20\x3D\x20","\x44\x69\x66\x66\x65\x72\x65\x6E\x63\x65\x20\x3D\x20","\x49\x6E\x76\x65\x72\x74\x65\x64\x20\x3D\x20","\x47\x65\x74\x53\x65\x72\x76\x65\x72\x53\x74\x72\x69\x6E\x67","\x20\x3A\x20","\x47\x65\x74\x4D\x61\x70\x4E\x61\x6D\x65","\x48\x65\x61\x64","\x4E\x65\x63\x6B","\x50\x65\x6C\x76\x69\x73","\x42\x6F\x64\x79","\x54\x68\x6F\x72\x61\x78","\x43\x68\x65\x73\x74","\x55\x70\x70\x65\x72\x20\x63\x68\x65\x73\x74","\x4C\x65\x66\x74\x20\x74\x68\x69\x67\x68","\x52\x69\x67\x68\x74\x20\x74\x68\x69\x67\x68","\x4C\x65\x66\x74\x20\x63\x61\x6C\x66","\x52\x69\x67\x68\x74\x20\x63\x61\x6C\x66","\x4C\x65\x66\x74\x20\x66\x6F\x6F\x74","\x52\x69\x67\x68\x74\x20\x66\x6F\x6F\x74","\x4C\x65\x66\x74\x20\x68\x61\x6E\x64","\x52\x69\x67\x68\x74\x20\x68\x61\x6E\x64","\x4C\x65\x66\x74\x20\x75\x70\x70\x65\x72\x20\x61\x72\x6D","\x4C\x65\x66\x74\x20\x66\x6F\x72\x65\x61\x72\x6D","\x52\x69\x67\x68\x74\x20\x75\x70\x70\x65\x72\x20\x61\x72\x6D","\x52\x69\x67\x68\x74\x20\x66\x6F\x72\x65\x61\x72\x6D","\x47\x65\x6E\x65\x72\x69\x63","\x74\x61\x72\x67\x65\x74\x5F\x69\x6E\x64\x65\x78","\x68\x69\x74\x62\x6F\x78","\x68\x69\x74\x63\x68\x61\x6E\x63\x65","\x73\x61\x66\x65\x70\x6F\x69\x6E\x74","\x47\x65\x74\x49\x6E\x61\x63\x63\x75\x72\x61\x63\x79","\x47\x65\x74\x53\x70\x72\x65\x61\x64","\x47\x65\x74\x56\x69\x65\x77\x41\x6E\x67\x6C\x65\x73","\x0A","\x53\x70\x72\x65\x61\x64\x20\x3D\x20","\x49\x6E\x61\x63\x63\x75\x72\x61\x63\x79\x20\x3D\x20","\x56\x69\x65\x77\x41\x6E\x67\x6C\x65\x73\x20\x3D\x20","\x50\x69\x6E\x67\x20\x3D\x20","\x50\x72\x69\x6E\x74\x43\x6F\x6C\x6F\x72","\x5B\x54\x41\x52\x47\x45\x54\x5D\x20\x3D\x20","\x5B\x48\x49\x54\x42\x4F\x58\x5D\x20\x3D\x20","\x5B\x48\x49\x54\x43\x48\x41\x4E\x43\x45\x5D\x20\x3D\x20","\x5B\x53\x41\x46\x45\x50\x4F\x49\x4E\x54\x5D\x20\x3D\x20","\x5B\x45\x58\x50\x4C\x4F\x49\x54\x5D\x20\x3D\x20","\x20\x0A","\x46\x61\x6B\x65\x20\x64\x65\x73\x79\x6E\x63","\x41\x74\x20\x74\x61\x72\x67\x65\x74\x73","\x41\x75\x74\x6F\x20\x64\x69\x72\x65\x63\x74\x69\x6F\x6E","\x47\x65\x74\x50\x6C\x61\x79\x65\x72\x73","\x6C\x65\x6E\x67\x74\x68","\x49\x73\x54\x65\x61\x6D\x6D\x61\x74\x65","\x61\x74\x74\x61\x63\x6B\x65\x72","\x64\x6D\x67\x5F\x68\x65\x61\x6C\x74\x68","\x43\x42\x61\x73\x65\x50\x6C\x61\x79\x65\x72","\x6D\x5F\x69\x48\x65\x61\x6C\x74\x68","\x43\x42\x61\x73\x65\x41\x74\x74\x72\x69\x62\x75\x74\x61\x62\x6C\x65\x49\x74\x65\x6D","\x6D\x5F\x69\x49\x74\x65\x6D\x44\x65\x66\x69\x6E\x69\x74\x69\x6F\x6E\x49\x6E\x64\x65\x78","\x52\x65\x76\x6F\x6C\x76\x65\x72\x20\x46\x69\x78","\x45\x6E\x61\x62\x6C\x65\x64","\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65","\x72\x61\x67\x65\x62\x6F\x74\x4C\x6F\x67\x73","\x52\x65\x67\x69\x73\x74\x65\x72\x43\x61\x6C\x6C\x62\x61\x63\x6B","\x70\x6C\x61\x79\x65\x72\x5F\x68\x75\x72\x74","\x43\x72\x65\x61\x74\x65\x4D\x6F\x76\x65","\x63\x72\x65\x61\x74\x65\x5F\x6D\x6F\x76\x65","\x44\x72\x61\x77","\x64\x72\x61\x77\x49\x74","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x35","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x34","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x33","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65\x32","\x6F\x6E\x5F\x72\x61\x67\x65\x62\x6F\x74\x5F\x66\x69\x72\x65","\x69\x6E\x76\x65\x72\x74","\x49\x6E\x69\x74\x69\x61\x6C\x69\x7A\x65","\x76\x69\x73\x75\x61\x6C\x73","\x4F\x6E\x48\x75\x72\x74","\x4F\x6E\x42\x75\x6C\x6C\x65\x74\x49\x6D\x70\x61\x63\x74","\x62\x75\x6C\x6C\x65\x74\x5F\x69\x6D\x70\x61\x63\x74","\x6F\x6E\x5F\x64\x72\x61\x77","\x77\x61\x74\x65\x72\x6D\x61\x72\x6B","\x57\x65\x6C\x63\x6F\x6D\x65\x20\x54\x6F\x20\x54\x61\x6E\x6B\x20\x53\x63\x68\x6F\x6F\x6C","\x50\x72\x69\x6E\x74"];
var master={dir:_$_18a6[0],cycle:false,iteration:1,showArrows:false,showCycle:false,showDegree:false,showInverted:false,getAAInvert:function()
{
	return UI[_$_18a6[4]](_$_18a6[1],_$_18a6[2],_$_18a6[3])
}
,setAAInvert:function()
{
	return UI[_$_18a6[5]](_$_18a6[1],_$_18a6[2],_$_18a6[3])
}
,getInvert:function()
{
	return UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[8],_$_18a6[9])
}
,setVisible:function()
{
	
}
};//1
function GetScriptOption(_0x2188E)
{
	var _0x218E1=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[8],_0x2188E);//18
	return _0x218E1
}
function invert()
{
	if(!master[_$_18a6[11]]()|| Entity[_$_18a6[14]](Event[_$_18a6[13]](_$_18a6[12]))!= Entity[_$_18a6[15]]())
	{
		return
	}
	//24
	master[_$_18a6[16]]()
}
function ui()
{
	UI[_$_18a6[18]](_$_18a6[17],0,0);UI[_$_18a6[18]](_$_18a6[19],0,0);UI[_$_18a6[21]](_$_18a6[20]);UI[_$_18a6[18]](_$_18a6[22],0,180);UI[_$_18a6[18]](_$_18a6[23],0.01,1);UI[_$_18a6[18]](_$_18a6[24],-180,180);UI[_$_18a6[21]](_$_18a6[25]);UI[_$_18a6[18]](_$_18a6[26],0,5);UI[_$_18a6[18]](_$_18a6[27],0.01,1);UI[_$_18a6[18]](_$_18a6[28],0,16);UI[_$_18a6[21]](_$_18a6[29]);UI[_$_18a6[30]](_$_18a6[9]);UI[_$_18a6[21]](_$_18a6[31]);UI[_$_18a6[30]](_$_18a6[32]);UI[_$_18a6[21]](_$_18a6[33]);UI[_$_18a6[21]](_$_18a6[34]);UI[_$_18a6[39]](_$_18a6[35],[_$_18a6[36],_$_18a6[37],_$_18a6[38]]);UI[_$_18a6[18]](_$_18a6[17],0,0);UI[_$_18a6[18]](_$_18a6[40],0,0);UI[_$_18a6[21]](_$_18a6[41]);UI[_$_18a6[30]](_$_18a6[42]);UI[_$_18a6[30]](_$_18a6[43]);UI[_$_18a6[30]](_$_18a6[44]);UI[_$_18a6[21]](_$_18a6[45]);UI[_$_18a6[21]](_$_18a6[17]);UI[_$_18a6[21]](_$_18a6[46]);UI[_$_18a6[30]](_$_18a6[47]);UI[_$_18a6[21]](_$_18a6[45]);UI[_$_18a6[21]](_$_18a6[17]);UI[_$_18a6[21]](_$_18a6[48]);UI[_$_18a6[30]](_$_18a6[49]);UI[_$_18a6[21]](_$_18a6[45]);UI[_$_18a6[21]](_$_18a6[17]);UI[_$_18a6[18]](_$_18a6[17],0,0);UI[_$_18a6[18]](_$_18a6[50],0,0);UI[_$_18a6[30]](_$_18a6[51]);UI[_$_18a6[53]](_$_18a6[52],1,58);UI[_$_18a6[55]](_$_18a6[54]);UI[_$_18a6[55]](_$_18a6[56]);UI[_$_18a6[18]](_$_18a6[17],0,0);UI[_$_18a6[18]](_$_18a6[57],0,0);var _0x21C1F=Global[_$_18a6[58]]();//85
	UI[_$_18a6[30]](_$_18a6[59]);UI[_$_18a6[53]](_$_18a6[60],0,_0x21C1F[0]);UI[_$_18a6[53]](_$_18a6[61],0,_0x21C1F[1]);UI[_$_18a6[18]](_$_18a6[17],0,0);UI[_$_18a6[18]](_$_18a6[62],0,0);UI[_$_18a6[30]](_$_18a6[63]);UI[_$_18a6[30]](_$_18a6[64]);UI[_$_18a6[18]](_$_18a6[17],0,0);UI[_$_18a6[18]](_$_18a6[65],0,0)
}
function yawvalues()
{
	var _0x216EF=Global[_$_18a6[66]]();//105
	var _0x22CFB=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[22]);//106
	var _0x22CA8=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[23]);//107
	var _0x22C55=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[24]);//108
	var _0x22C55=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[24]);//109
	var _0x20ED4=(_0x22CFB* Math[_$_18a6[68]]((_0x216EF)/ _0x22CA8)+ _0x22C55);//110
	return _0x20ED4
}
function Initialize()
{
	UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[70],yawvalues());UI[_$_18a6[71]](_$_18a6[1],_$_18a6[72],_$_18a6[73],fakelagRando())
}
function radian(_0x224E0)
{
	return _0x224E0* Math[_$_18a6[74]]/ 180.0
}
function ExtendVector(_0x21550,_0x21457,_0x214AA)
{
	var _0x214FD=radian(_0x21457);//128
	return [_0x214AA* Math[_$_18a6[68]](_0x214FD)+ _0x21550[0],_0x214AA* Math[_$_18a6[75]](_0x214FD)+ _0x21550[1],_0x21550[2]]
}
function VectorAdd(_0x211BF,_0x21212)
{
	return [_0x211BF[0]+ _0x21212[0],_0x211BF[1]+ _0x21212[1],_0x211BF[2]+ _0x21212[2]]
}
function VectorSubtract(_0x211BF,_0x21212)
{
	return [_0x211BF[0]- _0x21212[0],_0x211BF[1]- _0x21212[1],_0x211BF[2]- _0x21212[2]]
}
function VectorMultiply(_0x211BF,_0x21212)
{
	return [_0x211BF[0]* _0x21212[0],_0x211BF[1]* _0x21212[1],_0x211BF[2]* _0x21212[2]]
}
function VectorLength(_0x227CB,_0x20E81,_0x2281E)
{
	return Math[_$_18a6[76]](_0x227CB* _0x227CB+ _0x20E81* _0x20E81+ _0x2281E* _0x2281E)
}
function VectorNormalize(_0x22871)
{
	var _0x20F7A=VectorLength(_0x22871[0],_0x22871[1],_0x22871[2]);//154
	return [_0x22871[0]/ _0x20F7A,_0x22871[1]/ _0x20F7A,_0x22871[2]/ _0x20F7A]
}
function VectorDot(_0x211BF,_0x21212)
{
	return _0x211BF[0]* _0x21212[0]+ _0x211BF[1]* _0x21212[1]+ _0x211BF[2]* _0x21212[2]
}
function VectorDistance(_0x211BF,_0x21212)
{
	return VectorLength(_0x211BF[0]- _0x21212[0],_0x211BF[1]- _0x21212[1],_0x211BF[2]- _0x21212[2])
}
function ClosestPointOnRay(_0x210C6,_0x21073,_0x21020)
{
	var _0x21119=VectorSubtract(_0x210C6,_0x21073);//170
	var _0x20F27=VectorSubtract(_0x21020,_0x21073);//171
	var _0x20F7A=VectorLength(_0x20F27[0],_0x20F27[1],_0x20F27[2]);//172
	_0x20F27= VectorNormalize(_0x20F27);var _0x20FCD=VectorDot(_0x20F27,_0x21119);//175
	if(_0x20FCD< 0.0)
	{
		return _0x21073
	}
	//176
	if(_0x20FCD> _0x20F7A)
	{
		return _0x21020
	}
	//180
	return VectorAdd(_0x21073,VectorMultiply(_0x20F27,[_0x20FCD,_0x20FCD,_0x20FCD]))
}
function Flip()
{
	UI[_$_18a6[5]](_$_18a6[1],_$_18a6[2],_$_18a6[3])
}
var lastHitTime=0.0;//192
var lastImpactTimes=[0.0];//193
var lastImpacts=[[0.0,0.0,0.0]];//198
function OnHurt()
{
	if(GetScriptOption(_$_18a6[35])== 0)
	{
		return
	}
	//205
	if(Entity[_$_18a6[14]](Event[_$_18a6[13]](_$_18a6[12]))!== Entity[_$_18a6[15]]())
	{
		return
	}
	//206
	var _0x2248D=Event[_$_18a6[13]](_$_18a6[77]);//207
	if(_0x2248D== 1|| _0x2248D== 6|| _0x2248D== 7)
	{
		var _0x21E64=Global[_$_18a6[78]]();//211
		if(Math[_$_18a6[79]](lastHitTime- _0x21E64)> 0.5)
		{
			lastHitTime= _0x21E64;Flip()
		}
		
	}
	
}
function OnBulletImpact()
{
	if(GetScriptOption(_$_18a6[35])!== 2)
	{
		return
	}
	//222
	var _0x21E64=Global[_$_18a6[78]]();//224
	if(Math[_$_18a6[79]](lastHitTime- _0x21E64)< 0.5)
	{
		return
	}
	//225
	var _0x21EB7=Entity[_$_18a6[14]](Event[_$_18a6[13]](_$_18a6[12]));//227
	var _0x221A2=[Event[_$_18a6[81]](_$_18a6[80]),Event[_$_18a6[81]](_$_18a6[82]),Event[_$_18a6[81]](_$_18a6[83]),_0x21E64];//228
	var _0x2243A;//229
	if(Entity[_$_18a6[84]](_0x21EB7)&& Entity[_$_18a6[85]](_0x21EB7))
	{
		if(!Entity[_$_18a6[86]](_0x21EB7))
		{
			_0x2243A= Entity[_$_18a6[87]](_0x21EB7)
		}
		else 
		{
			if(Math[_$_18a6[79]](lastImpactTimes[_0x21EB7]- _0x21E64)< 0.1)
			{
				_0x2243A= lastImpacts[_0x21EB7]
			}
			else 
			{
				lastImpacts[_0x21EB7]= _0x221A2;lastImpactTimes[_0x21EB7]= _0x21E64;return
			}
			
		}
		//232
		var _0x21CC5=Entity[_$_18a6[15]]();//246
		var _0x22248=Entity[_$_18a6[87]](_0x21CC5);//247
		var _0x2229B=Entity[_$_18a6[90]](_0x21CC5,_$_18a6[88],_$_18a6[89]);//248
		var _0x221F5=VectorMultiply(VectorAdd(_0x22248,_0x2229B),[0.5,0.5,0.5]);//249
		var _0x21DBE=ClosestPointOnRay(_0x221F5,_0x2243A,_0x221A2);//251
		var _0x21D6B=VectorDistance(_0x221F5,_0x21DBE);//252
		if(_0x21D6B< 128.0)
		{
			var _0x222EE=Local[_$_18a6[91]]();//256
			var _0x21F0A=Local[_$_18a6[92]]();//257
			var _0x2214F=ClosestPointOnRay(_0x22248,_0x2243A,_0x221A2);//259
			var _0x220FC=VectorDistance(_0x22248,_0x2214F);//260
			var _0x220A9=ClosestPointOnRay(_0x2229B,_0x2243A,_0x221A2);//261
			var _0x22056=VectorDistance(_0x2229B,_0x220A9);//262
			var _0x21E11;//264
			var _0x22341;//265
			var _0x21F5D;//266
			if(_0x21D6B< _0x220FC&& _0x21D6B< _0x22056)
			{
				_0x21E11= _0x21DBE;_0x22341= ExtendVector(_0x21DBE,_0x222EE+ 180.0,10.0);_0x21F5D= ExtendVector(_0x21DBE,_0x21F0A+ 180.0,10.0)
			}
			else 
			{
				if(_0x22056< _0x220FC)
				{
					_0x21E11= _0x220A9;var _0x22394=ExtendVector(_0x21DBE,_0x222EE- 30.0+ 90.0,10.0);//277
					var _0x223E7=ExtendVector(_0x21DBE,_0x222EE- 30.0- 90.0,10.0);//278
					var _0x21FB0=ExtendVector(_0x21DBE,_0x21F0A- 30.0+ 90.0,10.0);//279
					var _0x22003=ExtendVector(_0x21DBE,_0x21F0A- 30.0- 90.0,10.0);//280
					if(VectorDistance(_0x220A9,_0x22394)< VectorDistance(_0x220A9,_0x223E7))
					{
						_0x22341= _0x22394
					}
					else 
					{
						_0x22341= _0x223E7
					}
					//281
					if(VectorDistance(_0x220A9,_0x21FB0)< VectorDistance(_0x220A9,_0x22003))
					{
						_0x21F5D= _0x21FB0
					}
					else 
					{
						_0x21F5D= _0x22003
					}
					
				}
				else 
				{
					_0x21E11= _0x2214F;_0x22341= ExtendVector(_0x21DBE,_0x222EE,10.0);_0x21F5D= ExtendVector(_0x21DBE,_0x21F0A,10.0)
				}
				
			}
			//268
			if(VectorDistance(_0x21E11,_0x21F5D)< VectorDistance(_0x21E11,_0x22341))
			{
				lastHitTime= _0x21E64;Flip()
			}
			
		}
		//254
		lastImpacts[_0x21EB7]= _0x221A2;lastImpactTimes[_0x21EB7]= _0x21E64
	}
	
}
function on_ragebot_fire()
{
	if(!UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[42]))
	{
		return
	}
	//320
	player= Entity[_$_18a6[15]]();weapon= Entity[_$_18a6[93]](player);weaponName= Entity[_$_18a6[94]](weapon);if(!(weaponName[_$_18a6[96]](_$_18a6[95])|| weaponName[_$_18a6[96]](_$_18a6[97])|| weaponName[_$_18a6[96]](_$_18a6[98])|| weaponName[_$_18a6[96]](_$_18a6[99])|| weaponName[_$_18a6[96]](_$_18a6[100])|| weaponName[_$_18a6[96]](_$_18a6[101])|| weaponName[_$_18a6[96]](_$_18a6[102])))
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[106],true);return
	}
	//326
	ragebot_target_exploit= Event[_$_18a6[13]](_$_18a6[107]);if(ragebot_target_exploit== 2)
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[106],true)
	}
	else 
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[106],false)
	}
	
}
function on_ragebot_fire5()
{
	if(!UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[47]))
	{
		return
	}
	//341
	player= Entity[_$_18a6[15]]();weapon= Entity[_$_18a6[93]](player);weaponName= Entity[_$_18a6[94]](weapon);if(!(weaponName[_$_18a6[96]](_$_18a6[95])|| weaponName[_$_18a6[96]](_$_18a6[97])|| weaponName[_$_18a6[96]](_$_18a6[98])|| weaponName[_$_18a6[96]](_$_18a6[99])|| weaponName[_$_18a6[96]](_$_18a6[100])|| weaponName[_$_18a6[96]](_$_18a6[101])|| weaponName[_$_18a6[96]](_$_18a6[102])))
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[106],false);return
	}
	//347
	ragebot_target_exploit= Event[_$_18a6[13]](_$_18a6[107]);if(ragebot_target_exploit== 1)
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[106],false)
	}
	else 
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[106],true)
	}
	
}
var inverter={get:function()
{
	return UI[_$_18a6[4]](_$_18a6[1],_$_18a6[108],_$_18a6[3])
}
,reverse:function()
{
	return UI[_$_18a6[5]](_$_18a6[1],_$_18a6[108],_$_18a6[3])
}
};//365
function deg2rad(_0x2116C)
{
	return _0x2116C* Math[_$_18a6[74]]/ 180.0
}
function angle_to_vec(_0x20D88,_0x20ED4)
{
	var _0x20D35=deg2rad(_0x20D88);//373
	var _0x20E81=deg2rad(_0x20ED4);//374
	var _0x20DDB=Math[_$_18a6[75]](_0x20D35);//375
	var _0x20C8F=Math[_$_18a6[68]](_0x20D35);//376
	var _0x20E2E=Math[_$_18a6[75]](_0x20E81);//377
	var _0x20CE2=Math[_$_18a6[68]](_0x20E81);//378
	return [_0x20C8F* _0x20CE2,_0x20C8F* _0x20E2E,-_0x20DDB]
}
function trace(_0x2262C,_0x225D9)
{
	var _0x226D2=angle_to_vec(_0x225D9[0],_0x225D9[1]);//382
	var _0x2267F=Entity[_$_18a6[109]](_0x2262C);//383
	_0x2267F[2]+= 50;var _0x22725=[_0x2267F[0]+ _0x226D2[0]* 8192,_0x2267F[1]+ _0x226D2[1]* 8192,(_0x2267F[2])+ _0x226D2[2]* 8192];//385
	var _0x22778=Trace[_$_18a6[110]](_0x2262C,_0x2267F,_0x22725);//386
	if(_0x22778[1]== 1.0)
	{
		return
	}
	//387
	_0x22725= [_0x2267F[0]+ _0x226D2[0]* _0x22778[1]* 8192,_0x2267F[1]+ _0x226D2[1]* _0x22778[1]* 8192,_0x2267F[2]+ _0x226D2[2]* _0x22778[1]* 8192];var distance=Math[_$_18a6[76]]((_0x2267F[0]- _0x22725[0])* (_0x2267F[0]- _0x22725[0])+ (_0x2267F[1]- _0x22725[1])* (_0x2267F[1]- _0x22725[1])+ (_0x2267F[2]- _0x22725[2])* (_0x2267F[2]- _0x22725[2]));//390
	_0x2267F= Render[_$_18a6[111]](_0x2267F);_0x22725= Render[_$_18a6[111]](_0x22725);if(_0x22725[2]!= 1|| _0x2267F[2]!= 1)
	{
		return
	}
	//393
	if(UI[_$_18a6[4]](_$_18a6[112],_$_18a6[113],_$_18a6[114],_$_18a6[115]))
	{
		Render[_$_18a6[110]](_0x2267F[0],_0x2267F[1],_0x22725[0],_0x22725[1],UI[_$_18a6[116]](_$_18a6[67],_$_18a6[56]));boo= _$_18a6[117]+ distance;Render[_$_18a6[118]](_0x22725[0],_0x22725[1],0,boo,UI[_$_18a6[116]](_$_18a6[67],_$_18a6[54]))
	}
	//395
	return distance
}
function on_draw()
{
	var _0x21CC5=Entity[_$_18a6[15]]();//404
	if(!Entity[_$_18a6[119]](_0x21CC5)||  !UI[_$_18a6[10]](_$_18a6[120],_$_18a6[7],_$_18a6[8],_$_18a6[51]))
	{
		return
	}
	//405
	if(Entity[_$_18a6[84]](_0x21CC5))
	{
		var _0x21D18;//409
		var _0x21C72=Entity[_$_18a6[90]](_0x21CC5,_$_18a6[121],_$_18a6[122]);//410
		left_distance= trace(_0x21CC5,[0,_0x21C72[1]- UI[_$_18a6[10]](_$_18a6[120],_$_18a6[7],_$_18a6[8],_$_18a6[52])]);right_distance= trace(_0x21CC5,[0,_0x21C72[1]+ UI[_$_18a6[10]](_$_18a6[120],_$_18a6[7],_$_18a6[8],_$_18a6[52])]);if(left_distance< right_distance)
		{
			if(inverter[_$_18a6[123]]())
			{
				inverter[_$_18a6[124]]()
			}
			
		}
		//414
		if(right_distance< left_distance)
		{
			if(!inverter[_$_18a6[123]]())
			{
				inverter[_$_18a6[124]]()
			}
			
		}
		
	}
	
}
function fakelagRando()
{
	var _0x216EF=Global[_$_18a6[66]]();//429
	var _0x2169C=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[26]);//430
	var _0x21649=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[27]);//431
	var _0x215F6=UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[28]);//432
	var _0x215A3=(_0x2169C* Math[_$_18a6[68]]((_0x216EF)/ _0x21649)+ _0x215F6);//433
	return _0x215A3
}
function on_ragebot_fire2()
{
	if(!UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[49]))
	{
		return
	}
	//445
	player= Entity[_$_18a6[15]]();weapon= Entity[_$_18a6[93]](player);weaponName= Entity[_$_18a6[94]](weapon);if(!(weaponName[_$_18a6[96]](_$_18a6[95])|| weaponName[_$_18a6[96]](_$_18a6[97])|| weaponName[_$_18a6[96]](_$_18a6[98])|| weaponName[_$_18a6[96]](_$_18a6[99])|| weaponName[_$_18a6[96]](_$_18a6[100])|| weaponName[_$_18a6[96]](_$_18a6[101])|| weaponName[_$_18a6[96]](_$_18a6[102])))
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[125],true);return
	}
	//451
	ragebot_target_exploit= Event[_$_18a6[13]](_$_18a6[107]);if(ragebot_target_exploit== 0)
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[125],true)
	}
	else 
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[105],_$_18a6[125],false)
	}
	
}
function on_ragebot_fire3()
{
	if(!UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[44]))
	{
		return
	}
	//466
	player= Entity[_$_18a6[15]]();weapon= Entity[_$_18a6[93]](player);weaponName= Entity[_$_18a6[94]](weapon);if(!(weaponName[_$_18a6[96]](_$_18a6[95])|| weaponName[_$_18a6[96]](_$_18a6[97])|| weaponName[_$_18a6[96]](_$_18a6[98])|| weaponName[_$_18a6[96]](_$_18a6[99])|| weaponName[_$_18a6[96]](_$_18a6[100])|| weaponName[_$_18a6[96]](_$_18a6[101])|| weaponName[_$_18a6[96]](_$_18a6[102])))
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[126],_$_18a6[127],true);return
	}
	//472
	ragebot_target_exploit= Event[_$_18a6[13]](_$_18a6[107]);if(ragebot_target_exploit== 2)
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[126],_$_18a6[127],true)
	}
	else 
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[126],_$_18a6[127],false)
	}
	
}
function on_ragebot_fire4()
{
	if(!UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[43]))
	{
		return
	}
	//487
	player= Entity[_$_18a6[15]]();weapon= Entity[_$_18a6[93]](player);weaponName= Entity[_$_18a6[94]](weapon);if(!(weaponName[_$_18a6[96]](_$_18a6[95])|| weaponName[_$_18a6[96]](_$_18a6[97])|| weaponName[_$_18a6[96]](_$_18a6[98])|| weaponName[_$_18a6[96]](_$_18a6[99])|| weaponName[_$_18a6[96]](_$_18a6[100])|| weaponName[_$_18a6[96]](_$_18a6[101])|| weaponName[_$_18a6[96]](_$_18a6[102])))
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[126],_$_18a6[127],true);return
	}
	//493
	ragebot_target_exploit= Event[_$_18a6[13]](_$_18a6[107]);if(ragebot_target_exploit== 1)
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[126],_$_18a6[127],true)
	}
	else 
	{
		UI[_$_18a6[71]](_$_18a6[103],_$_18a6[104],_$_18a6[126],_$_18a6[127],false)
	}
	
}
function HSVtoRGB(_0x219DA,_0x21B26,_0x21BCC)
{
	var _0x21AD3,_0x21987,_0x21212,_0x21A2D,_0x21934,_0x20D35,_0x21A80,_0x21B79;//510
	_0x21A2D= Math[_$_18a6[128]](_0x219DA* 6);_0x21934= _0x219DA* 6- _0x21A2D;_0x20D35= _0x21BCC* (1- _0x21B26);_0x21A80= _0x21BCC* (1- _0x21934* _0x21B26);_0x21B79= _0x21BCC* (1- (1- _0x21934)* _0x21B26);switch(_0x21A2D% 6)
	{
		case 0:_0x21AD3= 255,_0x21987= 0,_0x21212= 0;break//520
		case 1:_0x21AD3= 255,_0x21987= 0,_0x21212= 0;break//521
		case 2:_0x21AD3= 255,_0x21987= 0,_0x21212= 0;break//522
		case 3:_0x21AD3= 255,_0x21987= 0,_0x21212= 0;break//523
		case 4:_0x21AD3= 255,_0x21987= 0,_0x21212= 0;break//524
		case 5:_0x21AD3= 255,_0x21987= 0,_0x21212= 0;break
	}
	//518
	return {r:Math[_$_18a6[129]](_0x21AD3* 255),g:Math[_$_18a6[129]](_0x21987* 255),b:Math[_$_18a6[129]](_0x21212* 255)}
}
function getCustomValue(_0x21795)
{
	var _0x21742=UI[_$_18a6[10]](_$_18a6[120],_$_18a6[7],_$_18a6[67],_0x21795);//531
	return _0x21742
}
var position={x1:0,y1:0};//533
function watermark()
{
	if(UI[_$_18a6[10]](_$_18a6[6],_$_18a6[7],_$_18a6[67],_$_18a6[59],true))
	{
		var _0x228C4=HSVtoRGB(Global[_$_18a6[66]]()* UI[_$_18a6[10]](_$_18a6[120],_$_18a6[7],_$_18a6[8],_$_18a6[130]),1,1);//545
		const _0x22AB6=Math[_$_18a6[128]](Global[_$_18a6[131]]()* 1000/ 1.5);//547
		const _0x22917=Math[_$_18a6[128]](1/ Global[_$_18a6[132]]());//548
		x1= getCustomValue(_$_18a6[60]);y1= getCustomValue(_$_18a6[61]);var _0x22C02= new Date();//553
		var _0x229BD=_0x22C02[_$_18a6[133]]();//554
		var _0x22A63=_0x22C02[_$_18a6[134]]();//555
		var _0x22B5C=_0x22C02[_$_18a6[135]]();//556
		var _0x2296A=_0x229BD<= 9?_$_18a6[136]+ _0x22C02[_$_18a6[133]]()+ _$_18a6[137]:_0x22C02[_$_18a6[133]]()+ _$_18a6[137];//557
		var _0x22A10=_0x22A63<= 9?_$_18a6[136]+ _0x22C02[_$_18a6[134]]()+ _$_18a6[137]:_0x22C02[_$_18a6[134]]()+ _$_18a6[137];//558
		var _0x22B09=_0x22B5C<= 9?_$_18a6[136]+ _0x22C02[_$_18a6[135]]():_0x22C02[_$_18a6[135]]();//559
		var _0x22BAF=Global[_$_18a6[138]]();//564
		font= Render[_$_18a6[140]](_$_18a6[139],28,800);font2= Render[_$_18a6[140]](_$_18a6[139],10,600);font3= Render[_$_18a6[140]](_$_18a6[139],7,500);font4= Render[_$_18a6[140]](_$_18a6[139],8,600);font5= Render[_$_18a6[140]](_$_18a6[139],6,600);Render[_$_18a6[141]](x1+ 120,y1- 17,146,50,[30,30,30,140]);Render[_$_18a6[142]](x1+ 118,y1+ 5,150,29,[30,30,30,0]);Render[_$_18a6[142]](x1+ 119,y1- 17,147,50,[30,30,30,155]);Render[_$_18a6[141]](x1+ 120,y1+ 7,146,25,[30,30,30,215]);Render[_$_18a6[144]](x1+ 125,y1- 18,0,_$_18a6[143],[255,255,255,255],font2);Render[_$_18a6[144]](x1+ 125,y1- 5,0,_$_18a6[145],[255,255,255,255],font3);Render[_$_18a6[146]](x1+ 120,y1+ 8,133,2,1,[255,0,0,195],[255,0,0,255]);Render[_$_18a6[146]](x1+ 133,y1+ 8,133,2,1,[255,0,0,195],[255,0,0,255]);Render[_$_18a6[146]](x1+ 120,y1+ 9,133,2,1,[55,0,0,195],[55,0,0,255]);Render[_$_18a6[146]](x1+ 133,y1+ 9,133,2,1,[55,0,0,195],[55,0,0,255]);Render[_$_18a6[144]](x1+ 116,y1+ 15,0,_$_18a6[147]+ _0x22917,[255,255,255,254],font4);Render[_$_18a6[144]](x1+ 188,y1+ 14,0,_$_18a6[148],[155,155,155,0],font4);Render[_$_18a6[144]](x1+ 188,y1+ 8,0,_$_18a6[148],[155,155,155,0],font4);Render[_$_18a6[144]](x1+ 219,y1+ 15,0,_$_18a6[17]+ _0x22AB6+ _$_18a6[149],[255,255,255,220],font4);Render[_$_18a6[144]](x1+ 230,y1+ 16,0,_$_18a6[150],[255,255,255,0],font4);Render[_$_18a6[141]](x1+ 193,y1+ 13,2,15,[155,155,155,255]);Render[_$_18a6[142]](x1+ 129,y1+ 15,21,13,[255,202,0,225]);Render[_$_18a6[142]](x1+ 131,y1+ 13,21,13,[255,202,0,225]);Render[_$_18a6[141]](x1+ 128,y1+ 17,21,13,[30,30,30,255]);Render[_$_18a6[142]](x1+ 127,y1+ 17,21,13,[255,202,0,225]);Render[_$_18a6[144]](x1+ 131,y1+ 18,0,_$_18a6[151],[255,255,255,220],font5);Render[_$_18a6[141]](x1+ 199,y1+ 14,5,12,[43,253,28,255]);Render[_$_18a6[141]](x1+ 206,y1+ 17,5,9,[255,128,0,255]);Render[_$_18a6[141]](x1+ 213,y1+ 20,5,6,[255,0,0,255]);Render[_$_18a6[142]](x1+ 199,y1+ 14,6,13,[0,0,0,255]);Render[_$_18a6[142]](x1+ 206,y1+ 17,6,10,[0,0,0,255]);Render[_$_18a6[142]](x1+ 213,y1+ 20,6,7,[0,0,0,255])
	}
	
}
function main()
{
	var _0x21C1F=Global[_$_18a6[58]]()
}
function drawIt()
{
	fakeyaw= Local[_$_18a6[92]]();realyaw= Local[_$_18a6[91]]();var _0x213B1=Math[_$_18a6[79]](realyaw)- Math[_$_18a6[79]](fakeyaw);//621
	var _0x21404=UI[_$_18a6[4]](_$_18a6[1],_$_18a6[2],_$_18a6[3]);//622
	if(UI[_$_18a6[10]](_$_18a6[8],_$_18a6[63]))
	{
		Render[_$_18a6[118]](100,500,0,_$_18a6[152]+ fakeyaw[_$_18a6[153]](2),[247,99,88,255]);Render[_$_18a6[118]](100,520,0,_$_18a6[154]+ realyaw[_$_18a6[153]](2),[247,99,88,255]);Render[_$_18a6[118]](100,540,0,_$_18a6[155]+ Math[_$_18a6[79]](_0x213B1[_$_18a6[153]](2)),[247,99,88,255]);Render[_$_18a6[118]](100,580,0,_$_18a6[156]+ _0x21404,[99,206,99,250]);Render[_$_18a6[118]](100,600,0,World[_$_18a6[157]]()+ _$_18a6[158]+ Global[_$_18a6[159]](),[99,206,99,250])
	}
	
}
function getHitboxName(_0x2183B)
{
	var _0x217E8=_$_18a6[117];//634
	switch(_0x2183B)
	{
		case 0:_0x217E8= _$_18a6[160];break//637
		case 1:_0x217E8= _$_18a6[161];break//640
		case 2:_0x217E8= _$_18a6[162];break//643
		case 3:_0x217E8= _$_18a6[163];break//646
		case 4:_0x217E8= _$_18a6[164];break//649
		case 5:_0x217E8= _$_18a6[165];break//652
		case 6:_0x217E8= _$_18a6[166];break//655
		case 7:_0x217E8= _$_18a6[167];break//658
		case 8:_0x217E8= _$_18a6[168];break//661
		case 9:_0x217E8= _$_18a6[169];break//664
		case 10:_0x217E8= _$_18a6[170];break//667
		case 11:_0x217E8= _$_18a6[171];break//670
		case 12:_0x217E8= _$_18a6[172];break//673
		case 13:_0x217E8= _$_18a6[173];break//676
		case 14:_0x217E8= _$_18a6[174];break//679
		case 15:_0x217E8= _$_18a6[175];break//682
		case 16:_0x217E8= _$_18a6[176];break//685
		case 17:_0x217E8= _$_18a6[177];break//688
		case 18:_0x217E8= _$_18a6[178];break//691
		default:_0x217E8= _$_18a6[179]
	}
	//635
	return _0x217E8
}
function ragebotLogs()
{
	ragebot_target= Event[_$_18a6[13]](_$_18a6[180]);ragebot_target_hitbox= Event[_$_18a6[13]](_$_18a6[181]);ragebot_target_hitchance= Event[_$_18a6[13]](_$_18a6[182]);ragebot_target_safepoint= Event[_$_18a6[13]](_$_18a6[183]);ragebot_target_exploit= Event[_$_18a6[13]](_$_18a6[107]);targetName= Entity[_$_18a6[94]](ragebot_target);inaccuracy= Local[_$_18a6[184]]();spread= Local[_$_18a6[185]]();fakeyaw= Local[_$_18a6[92]]();realyaw= Local[_$_18a6[91]]();var _0x22586=Local[_$_18a6[186]]();//713
	var _0x22533=Math[_$_18a6[128]](1/ Local[_$_18a6[131]]());//714
	if(UI[_$_18a6[10]](_$_18a6[8],_$_18a6[64]))
	{
		Cheat[_$_18a6[192]]([247,99,88,255],_$_18a6[187]+ _$_18a6[188]+ spread+ _$_18a6[187]+ _$_18a6[189]+ inaccuracy+ _$_18a6[187]+ _$_18a6[152]+ fakeyaw+ _$_18a6[187]+ _$_18a6[154]+ realyaw+ _$_18a6[187]+ _$_18a6[190]+ _0x22586+ _$_18a6[187]+ _$_18a6[191]+ _0x22533+ _$_18a6[187]);Cheat[_$_18a6[192]]([247,99,88,255],_$_18a6[187]+ _$_18a6[193]+ targetName+ _$_18a6[187]+ _$_18a6[194]+ getHitboxName(ragebot_target_hitbox)+ _$_18a6[187]+ _$_18a6[195]+ ragebot_target_hitchance+ _$_18a6[187]+ _$_18a6[196]+ ragebot_target_safepoint+ _$_18a6[187]+ _$_18a6[197]+ ragebot_target_exploit+ _$_18a6[198])
	}
	//715
	_$_18a6[187]+ _$_18a6[189]+ inaccuracy
}
var old_fake_desync=UI[_$_18a6[10]](_$_18a6[1],_$_18a6[2],_$_18a6[199]);//724
var old_at_targets=UI[_$_18a6[10]](_$_18a6[1],_$_18a6[69],_$_18a6[200]);//725
var old_auto_direction=UI[_$_18a6[10]](_$_18a6[1],_$_18a6[69],_$_18a6[201]);//726
var old_yaw_offset=UI[_$_18a6[10]](_$_18a6[1],_$_18a6[69],_$_18a6[70]);//727
var prevent_correction=false;//728
var last_prevent_time=0;//729
var in_act_pha=false;//730
var in_act_pac=false;//731
var in_act_sr=false;//732
function distance(_0x211BF,_0x21212)
{
	ax= _0x211BF[0],ay= _0x211BF[1],az= _0x211BF[2];bx= _0x21212[0],by= _0x21212[1],bz= _0x21212[2];dx= ax- bx,dy= ay- by,dz= az- bz;return Math[_$_18a6[76]](dx* dx+ dy* dy+ dz* dz)
}
function distance2D(_0x21265,_0x2130B,_0x212B8,_0x2135E)
{
	xs= _0x212B8- _0x21265,ys= _0x2135E- _0x2130B;xs*= xs;ys*= ys;return Math[_$_18a6[76]](xs+ ys)
}
function difference(_0x211BF,_0x21212)
{
	if(_0x211BF> _0x21212)
	{
		return _0x211BF- _0x21212
	}
	else 
	{
		return _0x21212- _0x211BF
	}
	
}
function get_nearest_player()
{
	players= Entity[_$_18a6[202]]();local_origin= Entity[_$_18a6[109]](Entity[_$_18a6[15]]());target_origin= 0;target= 0;for(i= 0;i< players[_$_18a6[203]];i++)
	{
		if(!Entity[_$_18a6[119]](players[i]))
		{
			continue
		}
		//760
		if(Entity[_$_18a6[204]](players[i]))
		{
			continue
		}
		//764
		if(Entity[_$_18a6[86]](players[i]))
		{
			continue
		}
		//768
		entity_origin= Entity[_$_18a6[109]](players[i]);if(target=== 0)
		{
			target_origin= [999999,999999,999999]
		}
		//771
		if(distance(local_origin,target_origin)> distance(local_origin,entity_origin))
		{
			target= players[i];target_origin= entity_origin
		}
		
	}
	//759
	return target
}
function player_hurt()
{
	target= Event[_$_18a6[13]](_$_18a6[12]);attacker= Event[_$_18a6[13]](_$_18a6[205]);damage= Event[_$_18a6[13]](_$_18a6[206]);hitgroup= Event[_$_18a6[13]](_$_18a6[77]);if((Entity[_$_18a6[15]]()=== Entity[_$_18a6[14]](target))&& Entity[_$_18a6[15]]()!== Entity[_$_18a6[14]](attacker))
	{
		health= Entity[_$_18a6[90]](Entity[_$_18a6[15]](),_$_18a6[207],_$_18a6[208]);if(hitgroup=== 1&& (health/ damage)>= 2)
		{
			prevent_correction= true
		}
		else 
		{
			prevent_correction= false
		}
		
	}
	
}
function create_move()
{
	local_weapon_id= Entity[_$_18a6[90]](Entity[_$_18a6[93]](Entity[_$_18a6[15]]()),_$_18a6[209],_$_18a6[210]);local_origin= Entity[_$_18a6[90]](Entity[_$_18a6[15]](),_$_18a6[88],_$_18a6[89]);if(UI[_$_18a6[10]](_$_18a6[211]))
	{
		if(local_weapon_id=== 262208)
		{
			in_act_sr= Math[_$_18a6[129]](1/ Globals[_$_18a6[132]]())< 65?true:false;UI[_$_18a6[71]](_$_18a6[1],_$_18a6[72],_$_18a6[212],Math[_$_18a6[129]](1/ Globals[_$_18a6[132]]())< 65?false:true)
		}
		else 
		{
			in_act_sr= false;UI[_$_18a6[71]](_$_18a6[1],_$_18a6[72],_$_18a6[212],true)
		}
		
	}
	//797
	if(UI[_$_18a6[10]](_$_18a6[32]))
	{
		target= get_nearest_player();if(target=== 0||  !Entity[_$_18a6[119]](target))
		{
			in_act_pha= false;UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[200],old_at_targets);UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[201],old_auto_direction);UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[70],old_yaw_offset);return
		}
		//810
		local_origin= Entity[_$_18a6[109]](Entity[_$_18a6[15]]());target_origin= Entity[_$_18a6[109]](target);if((target_origin[2]> local_origin[2])&& difference(target_origin[2],local_origin[2])> 64&& distance2D(local_origin[0],local_origin[1],target_origin[0],target_origin[1])< 220)
		{
			in_act_pha= true;UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[200],true);UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[201],false);UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[70],180)
		}
		else 
		{
			in_act_pha= false;UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[200],old_at_targets);UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[201],old_auto_direction);UI[_$_18a6[71]](_$_18a6[1],_$_18a6[69],_$_18a6[70],old_yaw_offset)
		}
		
	}
	
}
function main()
{
	ui();Cheat[_$_18a6[215]](_$_18a6[213],_$_18a6[214]);Cheat[_$_18a6[215]](_$_18a6[216],_$_18a6[216]);Cheat[_$_18a6[215]](_$_18a6[217],_$_18a6[218]);Cheat[_$_18a6[215]](_$_18a6[219],_$_18a6[220]);Global[_$_18a6[215]](_$_18a6[213],_$_18a6[221]);Global[_$_18a6[215]](_$_18a6[213],_$_18a6[222]);Global[_$_18a6[215]](_$_18a6[213],_$_18a6[223]);Global[_$_18a6[215]](_$_18a6[213],_$_18a6[224]);Global[_$_18a6[215]](_$_18a6[213],_$_18a6[225]);Global[_$_18a6[215]](_$_18a6[216],_$_18a6[226]);Global[_$_18a6[215]](_$_18a6[219],_$_18a6[227],_$_18a6[217],_$_18a6[228],_$_18a6[229],_$_18a6[216]);Global[_$_18a6[215]](_$_18a6[216],_$_18a6[226],_$_18a6[219],_$_18a6[230],_$_18a6[231]);Global[_$_18a6[215]](_$_18a6[219],_$_18a6[232]);Global[_$_18a6[215]](_$_18a6[219],_$_18a6[233],_$_18a6[139]);UI[_$_18a6[71]](_$_18a6[120],_$_18a6[7],_$_18a6[8],_$_18a6[130],0.1);Global[_$_18a6[235]](_$_18a6[234])
}
main()