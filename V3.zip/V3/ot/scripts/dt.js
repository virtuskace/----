UI.AddHotkey("DT off Key");

function toggleHKey(){

    var active = UI.IsHotkeyActive("Script Items", "DT off Key"); //you don't have to store value in a variable, but just know you can if you think you'll need it more than once
    
    if(active === 1) toggled = false;
    else toggled = true;
    
    //since the method takes strings, variables containing strings can also be used
    UI.SetValue("Rage", "GENERAL", "Exploits", "Doubletap instant", toggled);

}

Global.RegisterCallback("CreateMove", "toggleHKey");